package twobackend.springmvc.dao;



import java.util.List;

import twobackend.springmvc.model.Persons;

public interface UserDao {
	Persons authenticate(Persons user);
	void updateUser(Persons user);
	Persons registerUser(Persons user);
	public List<Persons> getAllUsers(Persons user);

}
