package twobackend.springmvc.dao;

import java.util.List;

import twobackend.springmvc.model.Job;

public interface JobDao {
	
	void postJob(Job job);
	List<Job> getAllJobs();
	Job getJobDetail(int jobId);

}
