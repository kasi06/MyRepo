package twobackend.springmvc.dao;

import twobackend.springmvc.model.UploadFile;

public interface FileUploadDao {
	void save(UploadFile uploadFile);
	UploadFile getFile(String username);

}
