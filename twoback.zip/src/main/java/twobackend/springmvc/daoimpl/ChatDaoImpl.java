package twobackend.springmvc.daoimpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import twobackend.springmvc.dao.ChatDao;
import twobackend.springmvc.model.Persons;


@Repository
public class ChatDaoImpl implements ChatDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Persons> getOnlineUsers(String username) {
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from persons where isonline=true");
		List<Persons> onlineusers=query.list();
		return onlineusers;
	}

}
