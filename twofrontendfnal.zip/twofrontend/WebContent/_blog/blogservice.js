app.factory('BlogService',function($http){
	var blogService=this;
	var BASE_URL ="http://localhost:8081/twobackend"
		
	blogService.addPost=function(blogPost){
		console.log('addpost in service')
		return $http.post(BASE_URL + "/blog",blogPost);
	}
	blogService.getBlogPosts=function(){
		console.log('getBlogposts in service')
		return $http.get(BASE_URL + "/blog/list")
	}
	blogService.getBlogDetail=function(id){
		console.log('getBlogDetails')
		return $http.get(BASE_URL + "/blog/get/"+ id)
	}

	blogService.addComment=function(comment){
		return $http.post(BASE_URL + "/blog/comment",comment)
	}
	blogService.getComments=function(blogId){
		console.log('getcomments -- service')
		return $http.get(BASE_URL + "/blog/getcomments/"+blogId)
	}
	return blogService;
})