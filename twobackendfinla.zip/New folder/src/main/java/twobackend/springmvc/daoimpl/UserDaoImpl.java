package twobackend.springmvc.daoimpl;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import twobackend.springmvc.dao.UserDao;
import twobackend.springmvc.model.Persons;

@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	private SessionFactory sessionFactory;
		public SessionFactory getSessionFactory() {
			return sessionFactory;
		}
		public void setSessionFactory(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}
	
		@Override
		public Persons authenticate(Persons user) {
			Session session=sessionFactory.openSession();
			Query query=session.createQuery(
			"from Persons where username=?  and password=?");
			//select * from User where username='smith' and password='123'
			query.setString(0, user.getUsername());
			query.setString(1, user.getPassword());
			Persons validUser=(Persons)query.uniqueResult();
			session.close();
			return validUser;
		}
		@Override
		public void updateUser(Persons user) {
			Session session=sessionFactory.openSession();
			Persons existingUser=(Persons)session.get(Persons.class, user.getId());
			//update online status as true
			existingUser.setOnline(user.isOnline()); 
			
			session.update(existingUser);
			session.flush();
			session.close();
		}

		@Override
		public Persons registerUser(Persons user) {
			Session session=sessionFactory.openSession();
			session.save(user);
			session.flush();
			session.close();
			
			return user;
		}
		@Override
		public List<Persons> getAllUsers(Persons user) {
			Session session=sessionFactory.openSession();
			SQLQuery query=session.createSQLQuery("select * from persons where username in (select username from persons where username!=? minus(select to_id from friend where from_id=?and status!='D' union select from_id from friend where to_id=? and status!='D'))");
			query.setString(0, user.getUsername());
			query.setString(1, user.getUsername());
			query.setString(2, user.getUsername());
			query.addEntity(Persons.class);
			List<Persons> users=query.list();
			System.out.println(users);
			session.close();
			return users;
		}

}
