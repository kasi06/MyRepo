package twobackend.springmvc.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import twobackend.springmvc.dao.ChatDao;
import twobackend.springmvc.model.Error;
import twobackend.springmvc.model.Message;
import twobackend.springmvc.model.OutputMessage;
import twobackend.springmvc.model.Persons;


@RestController
@RequestMapping("/")
public class ChatController {
	

	  private Logger logger = LoggerFactory.getLogger(getClass());
	  
	  private ChatDao chatDao;

	  @MessageMapping("/chat")
	  @SendTo("/topic/message")
	  public OutputMessage sendMessage(Message message) {
	    logger.info("Message sent");
	    return new OutputMessage(message ,new Date());
	  }
	  
	
	  
	  @RequestMapping(value="/getAllousers", method=RequestMethod.GET)
	  public ResponseEntity<?> getAllousers(HttpSession session){
	    	Persons user=(Persons)session.getAttribute("user");
	    	if(user==null){
	    		System.out.println("USER is null");
	    		Error error=new Error(1,"Unauthorized user.. login using valid credentials");
				return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);//401
	    	}
	    	System.out.println("USER OBJECT " + user.getRole());
	    	List<Persons> onlineusers=chatDao.getOnlineUsers(user.getUsername());
	    	return new ResponseEntity<List<Persons>>(onlineusers,HttpStatus.OK);
	    }

}
