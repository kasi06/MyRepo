package twobackend.springmvc.dao;

import java.util.List;

import twobackend.springmvc.model.Persons;

public interface ChatDao {
	List<Persons> getOnlineUsers (String username);

}
