package twobackend.springmvc.dao;

import java.util.List;

import twobackend.springmvc.model.BlogComment;
import twobackend.springmvc.model.BlogPost;
import twobackend.springmvc.model.Persons;

public interface BlogDao {
	
	List<BlogPost> getBlogPosts();
	BlogPost getBlogPost(int id);
	BlogPost addBlogPost(Persons user,BlogPost blogPost);
	List<BlogComment> getBlogComments(int blogId);
	BlogPost addBlogPostComment(Persons user,BlogComment blogComment);

}
