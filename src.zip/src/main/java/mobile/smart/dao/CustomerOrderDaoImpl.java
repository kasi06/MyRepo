package mobile.smart.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mobile.smart.model.CustomerOrder;

@Repository("customerOrderDao")

public class CustomerOrderDaoImpl implements CustomerOrderDao {
	
	@Autowired
    private SessionFactory sessionFactory;
	

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}


	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	public void addCustomerOrder(CustomerOrder customerOrder) {
		
		Session session = sessionFactory.openSession();
        session.saveOrUpdate(customerOrder);
        session.flush();
        session.close();

	}

}
