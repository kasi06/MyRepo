package mobile.smart.dao;

import java.io.IOException;

import mobile.smart.model.Cart;

public interface CartDao {
	
	Cart getCartByCartId(int cartId);
	Cart validate(int cartId) throws IOException;

	void update(Cart cart);

}
