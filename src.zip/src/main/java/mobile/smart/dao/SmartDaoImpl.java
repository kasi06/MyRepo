package mobile.smart.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import mobile.smart.model.Smart;

@Repository("smartDao")
public class SmartDaoImpl implements SmartDao {
	
	@Autowired
	private SessionFactory sessionFactory;
		public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
		public List<Smart> getAllPhones() {
			Session session=sessionFactory.openSession();
			return session.createQuery("from Smart").list();
		}
		
		public Smart getPhoneById(int i) {
			//reading the record from the table
		  Session session=sessionFactory.openSession();
		  //select * from book where isbn=i
		  //if we call get method,Record doesnot exist it will return null
		  //if we call load, if the record doesnt exist it will throw exception
		  Smart phone=(Smart)session.get(Smart.class, i);  
		  session.close();
		  return phone;
		}
		
		public void deletePhone(int smaartid){
			Session session = sessionFactory.openSession();
			Smart phone = (Smart)session.get(Smart.class, smaartid);
			session.delete(phone);
			session.flush();
			session.close();
		}
		
		public void addPhone(Smart phone) {
			Session session=sessionFactory.openSession();
			session.save(phone);
			session.flush();
			session.close();	
	}

		public void editPhone(Smart phone) {
			Session session=sessionFactory.openSession();
			//update bookapp set ....where isbn=?
			session.update(phone);
			session.flush();
			session.close();
	}

		}
	
	

