package mobile.smart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class Ctrll {
	
	@RequestMapping(value = "/home")
	public ModelAndView goToHome(){
		
		ModelAndView hm = new ModelAndView("hom");
		return hm;
		
	}
	@RequestMapping(value = "/search")
	public ModelAndView goToSearch(){
		
		ModelAndView sea = new ModelAndView("search");
		return sea;
	}
	
	@RequestMapping(value = "/about" )
	public ModelAndView goToAbout(){
		ModelAndView abt = new ModelAndView("about");
		return abt;
	
	}

	@RequestMapping(value = "/login")
	public String login(@RequestParam(value="error",required=false) String error,
			@RequestParam(value="logout",required=false) String logout, 
			Model model){
			if(error!=null)
		model.addAttribute("error","Invalid username and password");
		
		if(logout!=null)
			model.addAttribute("logout","You have logged out successfully");
		return "login";

		
	}

	@RequestMapping(value = "/iphone")
	public ModelAndView goToiph(){
		
		ModelAndView i = new ModelAndView("ip");
		return i;
	}
	@RequestMapping(value = "/samsung")
	public ModelAndView goToSamsu(){
		
		ModelAndView sam = new ModelAndView("ssung");
		return sam;
	}	
	@RequestMapping(value = "/microsoft")
	public ModelAndView goToMicro(){
		
		ModelAndView ms = new ModelAndView("msft");
		return ms;
	}
	@RequestMapping(value = "/htc")
	public ModelAndView goToHttc(){
		
		ModelAndView h = new ModelAndView("ht");
		return h;
	}
	@RequestMapping(value = "/blackberry")
	public ModelAndView goToBberry(){
		
		ModelAndView bbr = new ModelAndView("bb");
		return bbr;
	}
	@RequestMapping(value = "/oneplus")
	public ModelAndView goToOplus(){
		
		ModelAndView op = new ModelAndView("ops");
		return op;
	}
	
	
	
}
