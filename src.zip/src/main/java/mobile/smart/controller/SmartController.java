package mobile.smart.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import mobile.smart.model.Manufacturer;
import mobile.smart.model.Smart;
import mobile.smart.Services.SmartService;

@Controller
public class SmartController {

	@Autowired
	private SmartService smartService;
 
	public SmartService getSmartService() {
		return smartService;
	}

	public void setSmartService(SmartService smartService) {
		this.smartService = smartService;
	}
	@RequestMapping("/getAllPhones")
	public@ResponseBody ModelAndView getAllProdcts(){
		List<Smart> phones = smartService.getAllphones();
		return new ModelAndView("phoneList","phones",phones);
	}

	@RequestMapping("getPhoneById/{smaartid}")
	public ModelAndView getPhoneById(@PathVariable(value="smaartid") int smaartid){
		Smart b=smartService.getPhoneById(smaartid);
		return new ModelAndView("phonePage","phoneObj",b);
	}
	
	@RequestMapping("admin/delete/{smaartid}")
	public String deleteBook(@PathVariable(value = "smaartid") int smaartid) {
	smartService.deletePhone(smaartid);
	return "redirect:/getAllPhones";
	}
	
	@RequestMapping(value="admin/phone/addPhone",method=RequestMethod.GET)
	public String getPhoneForm(Model model){
		Smart phone=new Smart();
		Manufacturer manufacturer=new Manufacturer();
		manufacturer.setMid(1);
		phone.setManufacturer(manufacturer);
		model.addAttribute("phoneFormObj",phone);
		return "phoneForm";

	}
	
	@RequestMapping(value="admin/phone/addPhone",method=RequestMethod.POST)
	public String addPhone(@Valid @ModelAttribute(value="phoneFormObj")  Smart phone, BindingResult result){
		
		if(result.hasErrors())
			return "phoneForm";
		smartService.addPhone(phone);
		
		
		MultipartFile image = phone.getSmartImage();
		
		System.out.println(phone.getSmartImage());
		if(image!=null && !image.isEmpty()){
		Path path = Paths.get("C:/Users/HOME/workspace/Gmob/src/main/webapp/resources/images/" + phone.getSmaartid() + ".png");
		try {
			image.transferTo(new File(path.toString()));
		} catch (IllegalStateException e) {
		 //TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		}
		
			return "redirect:/getAllPhones";
	}
	
	@RequestMapping("/admin/editPhone/{smaartid}")
	public ModelAndView getEditForm(@PathVariable(value="smaartid")  int smaartid){
		//First read the record which has to be updated
		//select * from bookapp where isbn=?
		//Populate the form with already existing value
		Smart phone=this.smartService.getPhoneById(smaartid);
		return new ModelAndView("editPhoneForm","editPhoneObj",phone);
	}
	@RequestMapping(value="/admin/editPhone",method=RequestMethod.POST)
	public String editPhone(@ModelAttribute(value="editPhoneObj") Smart phone)
	{
	smartService.editPhone(phone);
	return "redirect:/getAllPhones";
	}

	
}
