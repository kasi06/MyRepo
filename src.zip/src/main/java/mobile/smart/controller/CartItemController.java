package mobile.smart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import mobile.smart.Services.CartItemService;
import mobile.smart.Services.CartService;
import mobile.smart.Services.CustomerService;
import mobile.smart.Services.SmartService;
import mobile.smart.model.Cart;
import mobile.smart.model.CartItem;
import mobile.smart.model.Customer;
import mobile.smart.model.Smart;

@Controller
public class CartItemController {
	
	@Autowired
	private CartItemService cartItemService;
	@Autowired
	private CustomerService customerServices;
	
	@Autowired
	private SmartService smartService;
	
	@Autowired
	private CartService cartService;
	
	
	public SmartService getSmartService() {
		return smartService;
	}
	public void setSmartService(SmartService smartService) {
		this.smartService = smartService;
	}
	public CartService getCartService() {
		return cartService;
	}
	public void setCartService(CartService cartService) {
		this.cartService = cartService;
	}
	public CartItemService getCartItemService() {
		return cartItemService;
	}
	public void setCartItemService(CartItemService cartItemService) {
		this.cartItemService = cartItemService;
	}
	public CustomerService getCustomerServices() {
		return customerServices;
	}
	public void setCustomerServices(CustomerService customerServices) {
		this.customerServices = customerServices;
	}

	
	
	@RequestMapping("/cart/add/{smaartid}")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	public void addCartItem(@PathVariable(value = "smaartid") int smaartid){
		  //Is to get the username of the customer
		//User object contains details about the user -username , password, activeuser or not
		User user=(User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username=user.getUsername();
		Customer customer=customerServices.getCustomerByUsername(username);
		System.out.println("Customer is " + customer.getCustomerEmail() );
		Cart cart=customer.getCart();
		
		List<CartItem> cartItems=cart.getCartItem();
		Smart phone= smartService.getPhoneById(smaartid);
		for(int i=0;i<cartItems.size();i++){
			CartItem cartItem=cartItems.get(i);
			if(phone.getSmaartid()==cartItem.getPhone().getSmaartid()){
				cartItem.setQuantity(cartItem.getQuantity() + 1);
				cartItem.setTotalPrice(cartItem.getQuantity() * cartItem.getPhone().getPrice());
				cartItemService.addCartItem(cartItem);
				return;
			}
		}
		CartItem cartItem=new CartItem();
		cartItem.setQuantity(1);
		cartItem.setPrice(phone.getPrice());
		cartItem.setPhone(phone);
		cartItem.setTotalPrice(phone.getPrice() * 1);
		cartItem.setCart(cart);
		cartItemService.addCartItem(cartItem);
		
		
	}
	
	@RequestMapping("/cart/removecartitem/{cartItemId}")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	public void removeCartItem(
		@PathVariable(value="cartItemId") int cartItemId){
		cartItemService.removeCartItem(cartItemId);
	}

	@RequestMapping("/cart/removeAllItems/{cartId}")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	public void removeAllCartItems(@PathVariable(value="cartId") int cartId){
		Cart cart=cartService.getCartByCartId(cartId);
		cartItemService.removeAllCartItems(cart);
	}


		
		

	}

	
	



