package mobile.smart.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import mobile.smart.dao.SmartDao;
import mobile.smart.model.Smart;

@Service
public class SmartServiceImpl implements SmartService {

	@Autowired
	private SmartDao smartDao;

		public SmartDao getSmartDao() {
		return smartDao;
	}

	public void setSmartDao(SmartDao smartDao) {
		this.smartDao = smartDao;
	}
	  @Transactional
		public List<Smart> getAllphones() {
			return smartDao.getAllPhones();
		}

	  public Smart getPhoneById(int smartid) {
			return smartDao.getPhoneById(smartid);
		}
	  public void deletePhone(int smaartid) {
		  smartDao.deletePhone(smaartid);
		  }
	  public void addPhone(Smart phone) {
			smartDao.addPhone(phone);
			}

	public void editPhone(Smart phone) {
		smartDao.editPhone(phone);
	}

	
	
}
