package mobile.smart.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mobile.smart.dao.CustomerOrderDao;
import mobile.smart.model.Cart;
import mobile.smart.model.CartItem;
import mobile.smart.model.CustomerOrder;


@Service
public class CustomerOrderServiceImpl implements CustomerOrderService {

	
	 @Autowired
	    private CustomerOrderDao customerOrderDao;
	 

	    @Autowired
	    private CartService cartService;
	    
	    
	public CustomerOrderDao getCustomerOrderDao() {
			return customerOrderDao;
		}

		public void setCustomerOrderDao(CustomerOrderDao customerOrderDao) {
			this.customerOrderDao = customerOrderDao;
		}

		public CartService getCartService() {
			return cartService;
		}

		public void setCartService(CartService cartService) {
			this.cartService = cartService;
		}

	public void addCustomerOrder(CustomerOrder customerOrder) {
		customerOrderDao.addCustomerOrder(customerOrder);

	}

	public double getCustomerOrderGrandTotal(int cartId) {
		double grandTotal = 0;
        Cart cart = cartService.getCartByCartId(cartId);
        List<CartItem> cartItems = cart.getCartItem();

        for (CartItem item : cartItems){
            grandTotal += item.getTotalPrice();
        }

        return grandTotal;
	}

}
