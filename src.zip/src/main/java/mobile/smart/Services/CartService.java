package mobile.smart.Services;

import mobile.smart.model.Cart;

public interface CartService {

	Cart getCartByCartId(int cartId);
	
}
