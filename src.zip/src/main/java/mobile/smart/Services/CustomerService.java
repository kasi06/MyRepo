package mobile.smart.Services;

import java.util.List;

import mobile.smart.model.Customer;

public interface CustomerService {

	void addCustomer(Customer customer);
	List<Customer> getAllCustomers();
	Customer getCustomerByUsername(String username);
}
