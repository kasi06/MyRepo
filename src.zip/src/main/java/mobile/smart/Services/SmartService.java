package mobile.smart.Services;

import java.util.List;

import mobile.smart.model.Smart;

public interface SmartService {

		List<Smart> getAllphones();

		Smart getPhoneById(int smartid);
		void deletePhone(int smaartid);
		void addPhone(Smart phone);
		void editPhone(Smart phone);
		
}
