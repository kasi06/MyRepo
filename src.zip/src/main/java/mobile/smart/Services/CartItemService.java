package mobile.smart.Services;

import mobile.smart.model.Cart;
import mobile.smart.model.CartItem;

public interface CartItemService {
	
	void addCartItem(CartItem cartItem);
	void removeCartItem(int cartItemId);
	void removeAllCartItems(Cart cart);


}
