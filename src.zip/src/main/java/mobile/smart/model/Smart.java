package mobile.smart.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

import mobile.smart.model.Manufacturer;
@Entity
public class Smart implements Serializable {
	@Id
	@Column(name="smartID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
private int smaartid;
	
	@NotEmpty(message="Name is mandatory")
private String name;
private String description;
private double price;
@ManyToOne
@JoinColumn(name="mid")
private Manufacturer manufacturer;

@Transient
private MultipartFile smartImage;

public MultipartFile getSmartImage() {
	return smartImage;
}
public void setSmartImage(MultipartFile smartImage) {
	this.smartImage = smartImage;
}
public int getSmaartid() {
	return smaartid;
}
public void setSmaartid(int smaartid) {
	this.smaartid = smaartid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public Manufacturer getManufacturer() {
	return manufacturer;
}
public void setManufacturer(Manufacturer manufacturer) {
	this.manufacturer = manufacturer;
}




}
