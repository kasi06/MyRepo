package mobile.smart.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import mobile.smart.model.Smart;
@Entity
public class Manufacturer implements Serializable {
	@Id
	private int mid;
	@Column(name="Manufacturer")
	private String ManufacturerName;
	@OneToMany(mappedBy="manufacturer")
	@JsonIgnore
	List<Smart> phones;
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getManufacturerName() {
		return ManufacturerName;
	}
	public void setManufacturerName(String manufacturerName) {
		ManufacturerName = manufacturerName;
	}
	public List<Smart> getPhones() {
		return phones;
	}
	public void setPhones(List<Smart> phones) {
		this.phones = phones;
	}

}
