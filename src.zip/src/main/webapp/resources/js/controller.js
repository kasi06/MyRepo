var myapp=angular.module('myapp',[])
.controller('phoneController',function($scope,$http){
	
	
	$scope.getPhones=function(){
		$http.get('http://localhost:8081/Gmob/getPhoneList').success(function(data){
			alert('ikp')
			$scope.phones=data;
		})
	}

   $scope.addToCart=function(smaartid){
	   $http.put('http://localhost:8081/Gmob/cart/add/'+smaartid).success(function(){
		   alert('Added Successfully');
	   })
   }
   
   $scope.refreshCart=function(){
   	$http.get('http://localhost:8081/Gmob/cart/getCart/'+$scope.cartId).success(function(data){
   		$scope.cart=data;
   	})
   } 
   $scope.getCart=function(cartId){
   	$scope.cartId=cartId;
   	$scope.refreshCart(cartId);
   }
   
   $scope.removeFromCart=function(cartItemId){
   	    	$http.put(
'http://localhost:8081/Gmob/cart/removecartitem/'+cartItemId)
   	.success(function(){
   		alert('Deleted')
   		$scope.refreshCart();
   	})
   }
   
   $scope.clearCart=function(){
   	    	$http.put(
'http://localhost:8081/Gmob/cart/removeAllItems/'+$scope.cartId)
   	.success(function(){
   		$scope.refreshCart();
   	});
   }
   
   $scope.calculateGrandTotal=function(){
   	var grandTotal=0.0
   	for(var i=0;i<$scope.cart.cartItems.length;i++)
   		grandTotal=grandTotal+$scope.cart.cartItems[i].totalPrice;
   	return grandTotal;
   }

    
});
